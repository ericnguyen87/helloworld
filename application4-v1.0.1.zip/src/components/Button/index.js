import React from "react";
import PropTypes from "prop-types";

const shapes = {
  RoundedBorder8: "rounded-radius8",
  icbRoundedBorder4: "rounded-radius4",
  icbRoundedBorder8: "rounded-radius8",
};
const variants = {
  FillGray100: "bg-gray_100 text-gray_700",
  FillDeeporange50: "bg-deep_orange_50 text-red_700",
  OutlineGray400: "border border-gray_400 border-solid text-gray_901",
  icbFillGray100: "bg-gray_100",
  icbFillRed700: "bg-red_700",
};
const sizes = {
  sm: "p-[11px] 3xl:p-[13px] lg:p-[8px] xl:p-[9px]",
  smIcn: "p-[2px]",
  mdIcn: "3xl:p-[10px] lg:p-[7px] xl:p-[8px] p-[9px]",
};

const Button = ({
  children,
  className = "",
  leftIcon,
  rightIcon,
  shape,
  variant,
  size,
  ...restProps
}) => {
  return (
    <button
      className={`${className} ${shapes[shape] || ""} ${
        variants[variant] || ""
      } ${sizes[size] || ""} common-button `}
      {...restProps}
    >
      {!!leftIcon && leftIcon}
      {children}
      {!!rightIcon && rightIcon}
    </button>
  );
};

Button.propTypes = {
  className: PropTypes.string,
  children: PropTypes.node,
  shape: PropTypes.oneOf([
    "RoundedBorder8",
    "icbRoundedBorder4",
    "icbRoundedBorder8",
  ]),
  variant: PropTypes.oneOf([
    "FillGray100",
    "FillDeeporange50",
    "OutlineGray400",
    "icbFillGray100",
    "icbFillRed700",
  ]),
  size: PropTypes.oneOf(["sm", "smIcn", "mdIcn"]),
};
Button.defaultProps = {
  className: "",
  shape: "icbRoundedBorder4",
  variant: "icbFillGray100",
  size: "smIcn",
};

export { Button };
