import React from "react";

import {
  Column,
  Row,
  Img,
  Text,
  Stack,
  Line,
  Button,
  List,
  Input,
} from "components";

const BranddetailPage = () => {
  return (
    <>
      <Column className="bg-white_A700 font-barlow items-center justify-end mx-[auto] lg:pt-[16px] xl:pt-[18px] pt-[21px] 3xl:pt-[25px] w-[100%]">
        <Column className="items-center w-[65%]">
          <header className="w-[100%]">
            <Row className="items-center w-[100%]">
              <Img
                src="images/img_page1.png"
                className="lg:h-[32px] xl:h-[36px] h-[40px] 2xl:h-[41px] 3xl:h-[49px] w-[8%]"
                alt="PageOne"
              />
              <Text className="cursor-pointer hover:font-semibold font-semibold lg:ml-[171px] xl:ml-[195px] ml-[220px] 3xl:ml-[264px] lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-bluegray_900 w-[auto]">
                Gift solution
              </Text>
              <Text className="cursor-pointer hover:font-semibold font-semibold lg:ml-[23px] xl:ml-[26px] ml-[30px] 3xl:ml-[36px] lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-bluegray_900 w-[auto]">
                Buy vouchers
              </Text>
              <Text className="cursor-pointer hover:font-semibold font-semibold lg:ml-[23px] xl:ml-[26px] ml-[30px] 3xl:ml-[36px] lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-bluegray_900 w-[auto]">
                Partner brands
              </Text>
              <Text className="cursor-pointer hover:font-semibold font-semibold lg:ml-[23px] xl:ml-[26px] ml-[30px] 3xl:ml-[36px] lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-bluegray_900 w-[auto]">
                How to use
              </Text>
              <Text className="cursor-pointer hover:font-semibold font-semibold lg:ml-[23px] xl:ml-[26px] ml-[30px] 3xl:ml-[36px] lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-bluegray_900 w-[auto]">
                More
              </Text>
              <Img
                src="images/img_polygon1.svg"
                className="lg:h-[5px] h-[6px] 2xl:h-[7px] 3xl:h-[8px] ml-[2px] rounded-radius1 w-[1%]"
                alt="PolygonOne"
              />
              <Img
                src="images/img_minimize.svg"
                className="lg:h-[19px] xl:h-[22px] h-[24px] 2xl:h-[25px] 3xl:h-[29px] lg:ml-[23px] xl:ml-[26px] ml-[30px] 3xl:ml-[36px] lg:w-[18px] xl:w-[21px] w-[24px] 3xl:w-[28px]"
                alt="minimize"
              />
            </Row>
          </header>
          <Stack className="lg:h-[1372px] xl:h-[1570px] h-[1764px] 2xl:h-[1766px] 3xl:h-[2119px] lg:mt-[14px] xl:mt-[16px] mt-[18px] 3xl:mt-[21px] w-[100%]">
            <Img
              src="images/img_banner01.png"
              className="absolute lg:h-[288px] xl:h-[330px] h-[370px] 2xl:h-[371px] 3xl:h-[445px] rounded-radius16 top-[0] w-[100%]"
              alt="BannerOne"
            />
            <Column className="absolute bottom-[0] items-center w-[100%]">
              <Row className="items-end w-[91%]">
                <Stack className="bg-white_A700 border border-gray_400 border-solid lg:h-[108px] xl:h-[123px] h-[138px] 2xl:h-[139px] 3xl:h-[166px] lg:px-[11px] xl:px-[13px] px-[15px] 3xl:px-[18px] rounded-radius941 w-[16%]">
                  <Img
                    src="images/img_rectangle231.png"
                    className="absolute h-[105px] 2xl:h-[106px] 3xl:h-[127px] lg:h-[82px] xl:h-[94px] inset-[0] justify-center m-[auto] rounded-radius941 w-[76%]"
                    alt="Rectangle231"
                  />
                </Stack>
                <Column className="mb-[2px] lg:ml-[15px] xl:ml-[17px] ml-[20px] 3xl:ml-[24px] lg:mt-[55px] xl:mt-[63px] mt-[71px] 3xl:mt-[85px] w-[56%]">
                  <Text className="font-baijamjuree font-bold lg:text-[21px] xl:text-[24px] text-[28px] 3xl:text-[33px] text-gray_900 w-[auto]">
                    Highlands Coffee
                  </Text>
                  <Text className="font-barlow font-medium 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] mt-[9px] lg:text-[15px] xl:text-[17px] text-[20px] 3xl:text-[24px] text-gray_500 w-[auto]">
                    Cafe & Bánh
                  </Text>
                </Column>
                <Text className="font-normal lg:mb-[39px] xl:mb-[45px] mb-[51px] 3xl:mb-[61px] lg:ml-[15px] xl:ml-[17px] ml-[20px] 3xl:ml-[24px] lg:mt-[57px] xl:mt-[65px] mt-[74px] 3xl:mt-[88px] not-italic xl:text-[10px] text-[12px] 3xl:text-[14px] lg:text-[9px] text-gray_901 tracking-ls1 w-[auto]">
                  Trang chủ . All brands . Highland Coffee
                </Text>
              </Row>
              <Column className="lg:mt-[42px] xl:mt-[48px] mt-[55px] 3xl:mt-[66px] w-[100%]">
                <Text className="font-medium leading-[normal] lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-gray_901 w-[100%]">
                  <span className="text-gray_901 font-barlow font-normal not-italic">
                    Được sinh ra từ niềm đam mê bất tận với hạt cà phê Việt Nam.
                    Highlands Coffee đã không ngừng mang đến những sản phẩm cà
                    phê thơm ngon, sánh đượm trong không gian thoải mái và lịch
                    sự, dịch vụ chu đáo với mức giá phù hợp.
                    <br />
                    Được sinh ra từ niềm đam mê bất tận với hạt cà phê Việt Nam.
                    Highlands Coffee đã không ngừng mang đến những sản phẩm cà
                    phê thơm ngon, sánh đượm trong không gian thoải mái và lịch
                    sự, dịch vụ chu đáo với mức giá phù hợp.
                  </span>
                  <span className="text-gray_901 font-barlow font-normal not-italic">
                    Được sinh ra từ niềm đam mê bất tận với hạt cà phê Việt Nam.
                    <br />
                  </span>
                  <span className="text-gray_901 font-barlow font-normal underline not-italic">
                    Xem thêm
                    <br />
                  </span>
                  <span className="text-red_700 font-barlow font-normal underline not-italic">
                    Điều khoản chung
                  </span>
                  <span className="text-red_700 font-barlow font-normal not-italic">
                    {" "}
                  </span>
                  <span className="text-red_700 font-barlow font-normal not-italic">
                    {" "}
                  </span>
                  <span className="text-red_700 font-barlow font-normal underline not-italic">
                    Điều khoản chi tiết
                  </span>
                  <span className="text-red_700 font-barlow font-normal not-italic">
                    {" "}
                  </span>
                  <span className="text-red_700 font-barlow font-normal underline not-italic">
                    Lưu ý đặc biệt
                  </span>
                  <span className="text-red_700 font-barlow font-normal not-italic">
                    {" "}
                  </span>
                  <span className="text-red_700 font-barlow font-normal underline not-italic">
                    Xem hướng dẫn sử dụng
                  </span>
                </Text>
                <Line className="bg-gray_401 h-[1px] lg:mt-[37px] xl:mt-[42px] mt-[48px] 3xl:mt-[57px] w-[100%]" />
                <Text className="font-bold lg:mt-[43px] xl:mt-[49px] mt-[56px] 3xl:mt-[67px] lg:text-[17px] xl:text-[19px] text-[22px] 3xl:text-[26px] text-black_900 w-[auto]">
                  Thẻ quà tặng được sử dụng tại
                </Text>
                <Row className="items-center lg:mt-[20px] xl:mt-[23px] mt-[26px] 3xl:mt-[31px] w-[61%]">
                  <Button
                    className="font-normal not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-center w-[21%]"
                    shape="RoundedBorder8"
                    size="sm"
                    variant="FillDeeporange50"
                  >
                    Tại cửa hàng
                  </Button>
                  <Button
                    className="font-normal lg:ml-[12px] xl:ml-[14px] ml-[16px] 3xl:ml-[19px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-center w-[22%]"
                    shape="RoundedBorder8"
                    size="sm"
                    variant="FillGray100"
                  >
                    Qua web/app
                  </Button>
                  <Button
                    className="font-normal lg:ml-[12px] xl:ml-[14px] ml-[16px] 3xl:ml-[19px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-center w-[19%]"
                    shape="RoundedBorder8"
                    size="sm"
                    variant="FillGray100"
                  >
                    Qua hotline
                  </Button>
                  <Button
                    className="font-normal lg:ml-[12px] xl:ml-[14px] ml-[16px] 3xl:ml-[19px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-center w-[29%]"
                    shape="RoundedBorder8"
                    size="sm"
                    variant="FillGray100"
                  >
                    Điền mẫu đặt hàng
                  </Button>
                </Row>
                <Text className="font-normal lg:mt-[24px] xl:mt-[28px] mt-[32px] 3xl:mt-[38px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-gray_901 w-[auto]">
                  Đưa mã thẻ quà tặng cho nhân viên thu ngân tại các cửa hàng.
                </Text>
                <Row className="items-center lg:mt-[38px] xl:mt-[43px] mt-[49px] 3xl:mt-[58px] w-[100%]">
                  <Text className="font-barlow font-bold lg:text-[17px] xl:text-[19px] text-[22px] 3xl:text-[26px] text-black_900 w-[auto]">
                    Danh sách cửa hàng
                  </Text>
                  <Button
                    className="3xl:ml-[559px] flex items-center justify-center lg:ml-[362px] ml-[466px] text-center w-[15%] xl:ml-[414px]"
                    rightIcon={
                      <Img
                        src="images/img_polygon_3.svg"
                        className="w-[14px] ml-[18px] text-center lg:w-[10px] lg:ml-[14px] xl:w-[12px] xl:ml-[16px] 3xl:w-[16px] 3xl:ml-[21px] rounded-radius1"
                        alt="Polygon 3"
                      />
                    }
                    shape="RoundedBorder8"
                    size="sm"
                    variant="OutlineGray400"
                  >
                    <div className="bg-transparent font-normal font-roboto not-italic xl:text-[10px] text-[12px] 3xl:text-[14px] lg:text-[9px] tracking-ls1">
                      Hồ Chí Minh (69)
                    </div>
                  </Button>
                  <Row className="border border-gray_400 border-solid font-roboto items-center justify-between lg:ml-[12px] xl:ml-[14px] ml-[16px] 3xl:ml-[19px] 3xl:p-[10px] lg:p-[7px] xl:p-[8px] p-[9px] rounded-radius8 w-[13%]">
                    <Text className="font-normal ml-[1px] not-italic xl:text-[10px] text-[12px] 3xl:text-[14px] lg:text-[9px] text-gray_500 tracking-ls1 w-[auto]">
                      Quận/Huyện
                    </Text>
                    <Img
                      src="images/img_polygon_3.svg"
                      className="3xl:h-[10px] lg:h-[7px] h-[8px] 2xl:h-[9px] mr-[3px] rounded-radius1 w-[13%]"
                      alt="PolygonThree One"
                    />
                  </Row>
                </Row>
                <Row className="justify-between lg:mt-[18px] xl:mt-[21px] mt-[24px] 3xl:mt-[28px] w-[100%]">
                  <List
                    className="gap-[0] min-h-[auto] lg:pb-[11px] xl:pb-[13px] pb-[15px] 3xl:pb-[18px] w-[99%]"
                    orientation="vertical"
                  >
                    <Row className="lg:my-[13px] xl:my-[15px] my-[17.735px] 2xl:my-[17px] 3xl:my-[21px] w-[100%]">
                      <Text className="font-normal mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        <span className="text-gray_901 font-barlow font-bold">
                          Highlands Coffee - Pearl Plaza
                        </span>
                        <span className="text-gray_901 font-barlow"> </span>
                      </Text>
                      <Text className="font-normal lg:ml-[154px] xl:ml-[176px] ml-[198px] 3xl:ml-[237px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        028 71098400
                      </Text>
                      <Text className="font-normal lg:ml-[49px] xl:ml-[56px] ml-[64px] 3xl:ml-[76px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        561A Điện Biên Phủ, P.25, Q.Bình Thạnh, TP.HCM{" "}
                      </Text>
                      <Button className="flex lg:h-[13px] xl:h-[15px] h-[16px] 2xl:h-[17px] 3xl:h-[20px] items-center justify-center mb-[1px] 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] ml-[96px] lg:w-[12px] xl:w-[14px] w-[16px] 3xl:w-[19px]">
                        <Img
                          src="images/img_forward.svg"
                          className="h-[11px] flex items-center justify-center lg:h-[9px] xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px]"
                          alt="forward"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-gray_100" />
                    <Row className="lg:my-[13px] xl:my-[15px] my-[17.735px] 2xl:my-[17px] 3xl:my-[21px] w-[100%]">
                      <Text className="font-normal mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        <span className="text-gray_901 font-barlow font-bold">
                          Highlands Coffee - Pearl Plaza
                        </span>
                        <span className="text-gray_901 font-barlow"> </span>
                      </Text>
                      <Text className="font-normal lg:ml-[154px] xl:ml-[176px] ml-[198px] 3xl:ml-[237px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        028 71098400
                      </Text>
                      <Text className="font-normal lg:ml-[49px] xl:ml-[56px] ml-[64px] 3xl:ml-[76px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        561A Điện Biên Phủ, P.25, Q.Bình Thạnh, TP.HCM{" "}
                      </Text>
                      <Button className="flex lg:h-[13px] xl:h-[15px] h-[16px] 2xl:h-[17px] 3xl:h-[20px] items-center justify-center mb-[1px] 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] ml-[96px] lg:w-[12px] xl:w-[14px] w-[16px] 3xl:w-[19px]">
                        <Img
                          src="images/img_forward.svg"
                          className="h-[11px] flex items-center justify-center lg:h-[9px] xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px]"
                          alt="forward One"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-gray_100" />
                    <Row className="lg:my-[13px] xl:my-[15px] my-[17.735px] 2xl:my-[17px] 3xl:my-[21px] w-[100%]">
                      <Text className="font-normal mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        <span className="text-gray_901 font-barlow font-bold">
                          Highlands Coffee - Pearl Plaza
                        </span>
                        <span className="text-gray_901 font-barlow"> </span>
                      </Text>
                      <Text className="font-normal lg:ml-[154px] xl:ml-[176px] ml-[198px] 3xl:ml-[237px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        028 71098400
                      </Text>
                      <Text className="font-normal lg:ml-[49px] xl:ml-[56px] ml-[64px] 3xl:ml-[76px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        561A Điện Biên Phủ, P.25, Q.Bình Thạnh, TP.HCM{" "}
                      </Text>
                      <Button className="flex lg:h-[13px] xl:h-[15px] h-[16px] 2xl:h-[17px] 3xl:h-[20px] items-center justify-center mb-[1px] 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] ml-[96px] lg:w-[12px] xl:w-[14px] w-[16px] 3xl:w-[19px]">
                        <Img
                          src="images/img_forward.svg"
                          className="h-[11px] flex items-center justify-center lg:h-[9px] xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px]"
                          alt="forward Two"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-gray_100" />
                    <Row className="lg:my-[13px] xl:my-[15px] my-[17.735px] 2xl:my-[17px] 3xl:my-[21px] w-[100%]">
                      <Text className="font-normal mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        <span className="text-gray_901 font-barlow font-bold">
                          Highlands Coffee - Pearl Plaza
                        </span>
                        <span className="text-gray_901 font-barlow"> </span>
                      </Text>
                      <Text className="font-normal lg:ml-[154px] xl:ml-[176px] ml-[198px] 3xl:ml-[237px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        028 71098400
                      </Text>
                      <Text className="font-normal lg:ml-[49px] xl:ml-[56px] ml-[64px] 3xl:ml-[76px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        561A Điện Biên Phủ, P.25, Q.Bình Thạnh, TP.HCM{" "}
                      </Text>
                      <Button className="flex lg:h-[13px] xl:h-[15px] h-[16px] 2xl:h-[17px] 3xl:h-[20px] items-center justify-center mb-[1px] 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] ml-[96px] lg:w-[12px] xl:w-[14px] w-[16px] 3xl:w-[19px]">
                        <Img
                          src="images/img_forward.svg"
                          className="h-[11px] flex items-center justify-center lg:h-[9px] xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px]"
                          alt="forward Three"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-gray_100" />
                    <Row className="lg:my-[13px] xl:my-[15px] my-[17.735px] 2xl:my-[17px] 3xl:my-[21px] w-[100%]">
                      <Text className="font-normal mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        <span className="text-gray_901 font-barlow font-bold">
                          Highlands Coffee - Pearl Plaza
                        </span>
                        <span className="text-gray_901 font-barlow"> </span>
                      </Text>
                      <Text className="font-normal lg:ml-[154px] xl:ml-[176px] ml-[198px] 3xl:ml-[237px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        028 71098400
                      </Text>
                      <Text className="font-normal lg:ml-[49px] xl:ml-[56px] ml-[64px] 3xl:ml-[76px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        561A Điện Biên Phủ, P.25, Q.Bình Thạnh, TP.HCM{" "}
                      </Text>
                      <Button className="flex lg:h-[13px] xl:h-[15px] h-[16px] 2xl:h-[17px] 3xl:h-[20px] items-center justify-center mb-[1px] 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] ml-[96px] lg:w-[12px] xl:w-[14px] w-[16px] 3xl:w-[19px]">
                        <Img
                          src="images/img_forward.svg"
                          className="h-[11px] flex items-center justify-center lg:h-[9px] xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px]"
                          alt="forward Four"
                        />
                      </Button>
                    </Row>
                    <Line className="self-center w-[100%] h-[1px] bg-gray_100" />
                    <Row className="lg:my-[13px] xl:my-[15px] my-[17.735px] 2xl:my-[17px] 3xl:my-[21px] w-[100%]">
                      <Text className="font-normal mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        <span className="text-gray_901 font-barlow font-bold">
                          Highlands Coffee - Pearl Plaza
                        </span>
                        <span className="text-gray_901 font-barlow"> </span>
                      </Text>
                      <Text className="font-normal lg:ml-[154px] xl:ml-[176px] ml-[198px] 3xl:ml-[237px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        028 71098400
                      </Text>
                      <Text className="font-normal lg:ml-[49px] xl:ml-[56px] ml-[64px] 3xl:ml-[76px] mt-[3px] not-italic lg:text-[10px] xl:text-[12px] text-[14px] 3xl:text-[16px] text-gray_901 w-[auto]">
                        561A Điện Biên Phủ, P.25, Q.Bình Thạnh, TP.HCM{" "}
                      </Text>
                      <Button className="flex lg:h-[13px] xl:h-[15px] h-[16px] 2xl:h-[17px] 3xl:h-[20px] items-center justify-center mb-[1px] 3xl:ml-[115px] lg:ml-[74px] xl:ml-[85px] ml-[96px] lg:w-[12px] xl:w-[14px] w-[16px] 3xl:w-[19px]">
                        <Img
                          src="images/img_forward.svg"
                          className="h-[11px] flex items-center justify-center lg:h-[9px] xl:h-[10px] 2xl:h-[12px] 3xl:h-[14px]"
                          alt="forward Five"
                        />
                      </Button>
                    </Row>
                  </List>
                  <Line className="bg-gray_100 lg:h-[117px] xl:h-[134px] h-[150px] 2xl:h-[151px] 3xl:h-[181px] rounded-radius2 w-[4px]" />
                </Row>
                <Stack className="lg:h-[288px] xl:h-[330px] h-[370px] 2xl:h-[371px] 3xl:h-[445px] lg:mt-[40px] xl:mt-[46px] mt-[52px] 3xl:mt-[62px] w-[100%]">
                  <Img
                    src="images/img_vector20.png"
                    className="absolute lg:h-[288px] xl:h-[330px] h-[370px] 2xl:h-[371px] 3xl:h-[445px] right-[0] w-[69%]"
                    alt="VectorTwenty One"
                  />
                  <Img
                    src="images/img_website1.png"
                    className="absolute lg:h-[288px] xl:h-[330px] h-[370px] 2xl:h-[371px] 3xl:h-[445px] rounded-radius16 w-[100%]"
                    alt="WebsiteOne"
                  />
                </Stack>
              </Column>
            </Column>
          </Stack>
        </Column>
        <Column className="bg-red_A200_5e items-center justify-end lg:mt-[46px] xl:mt-[53px] mt-[60px] 3xl:mt-[72px] lg:p-[41px] xl:p-[47px] p-[53px] 3xl:p-[63px] w-[100%]">
          <Row className="items-center justify-center 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] mt-[9px] w-[70%]">
            <Column className="mt-[1px] w-[43%]">
              <Text className="font-bold lg:text-[11px] xl:text-[13px] text-[15px] 3xl:text-[18px] text-bluegray_900 w-[auto]">
                <span className="text-bluegray_900 font-barlow">
                  Don’t miss
                </span>
                <span className="text-red_700 font-barlow">
                  {" "}
                  updates and promotions
                </span>
                <span className="text-bluegray_900 font-barlow"> from us!</span>
              </Text>
              <Row className="items-center 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] mt-[9px] w-[73%]">
                <Input
                  className="font-normal not-italic p-[0] lg:text-[11px] xl:text-[13px] text-[15px] 3xl:text-[18px] placeholder:text-bluegray_900 text-bluegray_900 w-[100%]"
                  wrapClassName="mb-[1px] w-[83%]"
                  type="email"
                  name="GroupTwo"
                  placeholder="Your email"
                ></Input>
                <Button
                  className="flex lg:h-[28px] xl:h-[32px] h-[35px] 2xl:h-[36px] 3xl:h-[43px] items-center justify-center lg:ml-[10px] xl:ml-[11px] ml-[13px] 3xl:ml-[15px] mt-[1px] lg:w-[27px] xl:w-[31px] w-[35px] 3xl:w-[42px]"
                  shape="icbRoundedBorder8"
                  size="mdIcn"
                  variant="icbFillRed700"
                >
                  <Img
                    src="images/img_arrowright.svg"
                    className="h-[16px] flex items-center justify-center lg:h-[13px] xl:h-[15px] 2xl:h-[17px] 3xl:h-[20px]"
                    alt="arrowright"
                  />
                </Button>
              </Row>
              <Row className="items-end ml-[1px] lg:mt-[13px] xl:mt-[15px] mt-[17px] 3xl:mt-[20px] w-[72%]">
                <Img
                  src="images/img_page1_black_900.png"
                  className="lg:h-[29px] xl:h-[33px] h-[37px] 2xl:h-[38px] 3xl:h-[45px] mb-[1px] w-[25%]"
                  alt="PageOne One"
                />
                <Img
                  src="images/img_group26.svg"
                  className="lg:h-[22px] xl:h-[25px] h-[28px] 2xl:h-[29px] 3xl:h-[34px] lg:ml-[49px] xl:ml-[56px] ml-[63px] 3xl:ml-[75px] 3xl:mt-[10px] lg:mt-[7px] xl:mt-[8px] mt-[9px] w-[53%]"
                  alt="GroupTwentySix"
                />
              </Row>
            </Column>
            <Column className="w-[17%]">
              <Text className="font-normal not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-black_900 w-[auto]">
                About us
              </Text>
              <Text className="font-normal lg:mt-[20px] xl:mt-[23px] mt-[26px] 3xl:mt-[31px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-black_900_71 w-[auto]">
                Careers
              </Text>
              <Text className="font-normal lg:mt-[21px] xl:mt-[24px] mt-[28px] 3xl:mt-[33px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-black_900_71 w-[auto]">
                Blogs
              </Text>
            </Column>
            <Column className="items-center w-[40%]">
              <Row className="items-center justify-between w-[100%]">
                <Text className="font-normal not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-black_900 w-[auto]">
                  How to use
                </Text>
                <Img
                  src="images/img_bitmap.png"
                  className="lg:h-[29px] xl:h-[33px] h-[37px] 2xl:h-[38px] 3xl:h-[45px] w-[25%]"
                  alt="Bitmap"
                />
              </Row>
              <Row className="justify-evenly lg:mt-[10px] xl:mt-[12px] mt-[14px] 3xl:mt-[16px] w-[100%]">
                <Column className="mb-[3px] w-[75%]">
                  <Text className="font-normal not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-black_900 w-[auto]">
                    Policy information
                  </Text>
                  <Text className="font-normal lg:mt-[20px] xl:mt-[23px] mt-[26px] 3xl:mt-[31px] not-italic lg:text-[14px] xl:text-[16px] text-[18px] 3xl:text-[21px] text-black_900 w-[auto]">
                    FAQs
                  </Text>
                </Column>
                <Img
                  src="images/img_filelogoiso2.png"
                  className="lg:h-[48px] xl:h-[55px] h-[61px] 2xl:h-[62px] 3xl:h-[74px] mt-[4px] w-[24%]"
                  alt="filelogoISOTwo"
                />
              </Row>
            </Column>
          </Row>
          <Line className="bg-gray_404 h-[1px] lg:mt-[35px] xl:mt-[40px] mt-[45px] 3xl:mt-[54px] w-[70%]" />
          <Row className="items-center justify-between lg:mt-[13px] xl:mt-[15px] mt-[17px] 3xl:mt-[20px] w-[70%]">
            <Text className="font-normal not-italic lg:text-[12px] xl:text-[14px] text-[16px] 3xl:text-[19px] text-bluegray_900 w-[auto]">
              Copyright © DayOne JSC. All right reserved
            </Text>
            <Img
              src="images/img_group3837.svg"
              className="lg:h-[20px] xl:h-[23px] h-[25px] 2xl:h-[26px] 3xl:h-[31px] w-[15%]"
              alt="Group3837"
            />
          </Row>
        </Column>
      </Column>
    </>
  );
};

export default BranddetailPage;
